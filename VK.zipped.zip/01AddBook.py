import pymysql

con=pymysql.connect(host='bjc9hazrvlfytz7lqn1z-mysql.services.clever-cloud.com',user='uvo4jcsjw5bzlm1y',password='TKfzEEAlWSe01SaNEs9x',database='bjc9hazrvlfytz7lqn1z')
curs=con.cursor()


try:

    Bookcode=int(input("Enter Bookcode Number :"))
    Bookname=input("Enter Bookname :")
    Category=input("Enter Category : ")
    Author=input("Enter Author Name :")
    Publication=int(input("Enter Publication Year :"))
    Edition=int(input("Enter Edition Number :"))
    Price=float(input("Enter Price Of Book : "))
    review=input("Enter review :")
    
    curs.execute("INSERT INTO Books Values(%d,'%s','%s','%s',%d,%d,'%.2f','%s')"%(Bookcode,Bookname,Category,Author,Publication,Edition,Price,review))
    con.commit()
    print("Book Inserte Successfully...")
except Exception as e:
    print('Enter Valid Input..')
    print("Error:",e)

con.close()

