import pymysql
con=pymysql.connect(host='bjc9hazrvlfytz7lqn1z-mysql.services.clever-cloud.com',user='uvo4jcsjw5bzlm1y',password='TKfzEEAlWSe01SaNEs9x',database='bjc9hazrvlfytz7lqn1z')
curs=con.cursor()

try:
    auth=input("Enter the author name : ")
    pub=int(input("Enter the publication year :"))

    curs.execute("select * from Books where Author='%s' and Publication=%d"%(auth,pub))
    data=curs.fetchall()
    print(data)

except Exception as e:
    print("Error:",e)

con.close()