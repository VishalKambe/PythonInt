import pymysql
con=pymysql.connect(host='bjc9hazrvlfytz7lqn1z-mysql.services.clever-cloud.com',user='uvo4jcsjw5bzlm1y',password='TKfzEEAlWSe01SaNEs9x',database='bjc9hazrvlfytz7lqn1z')
curs=con.cursor()
try:
    code=int(input("Enter bookcode : "))
    curs.execute("select * from Books where Bookcode=%d"%code)
    data=curs.fetchone()
    print(data)
    if data:
        review=input("Enter your review :")
        curs.execute("update Books set review='%s' where Bookcode=%d"%(review,code))
        con.commit()
        print("Review saved...")
    else:
        print(" Book  does not exist ")
except Exception as e:
    print('Error :',e)

con.close()