import pymysql
con=pymysql.connect(host='bjc9hazrvlfytz7lqn1z-mysql.services.clever-cloud.com',user='uvo4jcsjw5bzlm1y',password='TKfzEEAlWSe01SaNEs9x',database='bjc9hazrvlfytz7lqn1z')
curs=con.cursor()

try:
    code=int(input("Enter the bookcode :"))
    curs.execute("select * from Books where bookcode=%d"%code)
    data=curs.fetchone()
    if (data):
        print(data)

        delete=input("Do you want to delete this book? : (Type-yes)   ")
        if delete.lower()=="yes":
            curs.execute("delete from Books where Bookcode=%d"%code)
            con.commit()
            print("Book Deleted Successfully...")
        else:
            print('Invalid Input..')

    else:
        print('Book Does Not Exist..')
    
except Exception as e:
    print('Error : ',e)

con.close()
