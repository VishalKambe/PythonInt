import pymysql
con=pymysql.connect(host='bjc9hazrvlfytz7lqn1z-mysql.services.clever-cloud.com',user='uvo4jcsjw5bzlm1y',password='TKfzEEAlWSe01SaNEs9x',database='bjc9hazrvlfytz7lqn1z')
curs=con.cursor()
code=int(input('Enter Bookcode Number : '))
try:
    curs.execute("select * from Books where Bookcode='%d'" %code)
    res=curs.fetchone()

    print(res)

except Exception as e:
    print("Book does not exist..")
    print('Error:',e)

con.close()