
import pymysql
con=pymysql.connect(host='bjc9hazrvlfytz7lqn1z-mysql.services.clever-cloud.com',user='uvo4jcsjw5bzlm1y',password='TKfzEEAlWSe01SaNEs9x',database='bjc9hazrvlfytz7lqn1z')
curs=con.cursor()

curs=con.cursor()
cat=input("Enter your Category :(Romance/Action/Comedy?Biography) ")
curs.execute("select * from Books where Category='%s'" %cat)
data=curs.fetchall()
print(data)
con.close()

