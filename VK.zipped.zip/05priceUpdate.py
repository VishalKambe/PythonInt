import pymysql
con=pymysql.connect(host='bjc9hazrvlfytz7lqn1z-mysql.services.clever-cloud.com',user='uvo4jcsjw5bzlm1y',password='TKfzEEAlWSe01SaNEs9x',database='bjc9hazrvlfytz7lqn1z')
curs=con.cursor()
try:
    code=int(input("Enter the Bookcode To Update Book Price: "))
    curs.execute("select * from Books where bookcode=%d"%code)
    data=curs.fetchone()
    if data:
        newp=int(input("Enter the updated price :"))
        curs.execute("update Books set price=%d"%newp)
        con.commit()
        print("Book price updated successfully...")
    else:
        print("Sorry Book does not exist")
except Exception as e:
    print("Error :",e)

con.close()