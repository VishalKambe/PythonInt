import pymysql

con=pymysql.connect(host='bjc9hazrvlfytz7lqn1z-mysql.services.clever-cloud.com',user='uvo4jcsjw5bzlm1y',password='TKfzEEAlWSe01SaNEs9x',database='bjc9hazrvlfytz7lqn1z')
curs=con.cursor()
curs.execute("select * from Books")
data=curs.fetchall()

for rec in data:
    print(rec)
  
con.close()